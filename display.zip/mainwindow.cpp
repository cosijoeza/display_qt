#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core/core.hpp>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <iostream>
#include <QPixmap>
#include <QFile>
#include "ui_mainwindow.h"
#include "mainwindow.h"
#include "functions.h"

using namespace cv;
using namespace std;

Mat image_1,image_2,resultado;
String picture1_path="", picture2_path="";
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_logicas_activated(int index)
{
    switch(index)
    {
        case 0:
            cout << "Suma"<<endl;
            resultado = funSuma(image_1,image_2);
            break;
        case 1:
            cout << "Resta"<<endl;
            resultado = funResta(image_1,image_2);
            break;
        case 2:
            cout << "Resta Normalizada"<<endl;
            resultado = funRestaNorm(image_1,image_2);
            break;
        case 3:
            cout << "And"<<endl;
            resultado = funAnd(image_1,image_2);
            break;
        case 4:
            cout << "Or"<<endl;
            resultado = funOr(image_1,image_2);
            break;
        case 5:
            resultado = negative(image_1);
            cout << "Negative"<<endl;
            break;

    }
    imwrite("resultado.jpg",resultado);
    QPixmap pix("resultado.jpg");
    int w = ui->resultado->width();
    int h = ui->resultado->height();
    ui->resultado->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
    return;
}

void MainWindow::on_canales_activated(int index)
{
    resultado = funGetChannel(image_1,index);

    imwrite("resultado.jpg",resultado);
    QPixmap pix("resultado.jpg");
    int w = ui->resultado->width();
    int h = ui->resultado->height();
    ui->resultado->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
    return;
}

void MainWindow::on_geometricas_activated(int index)
{
    cout << index << endl;
    switch(index)
    {
        case 0:
            cout << "1:2"<<endl;
            resultado = escala(image_1,2);
            break;
        case 1:
            cout << "1:4"<<endl;
            resultado = escala(image_1,4);
            break;
        case 2:
            cout << "1:8"<<endl;
            resultado = escala(image_1,8);
            break;
    }
    imwrite("resultado.jpg",resultado);
    QPixmap pix("resultado.jpg");
    int w = ui->resultado->width();
    int h = ui->resultado->height();
    ui->resultado->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
    return;
}

void MainWindow::on_open1_clicked()
{
    QFile file;
    QTextStream io;
    QString file_name;
    file_name = QFileDialog::getOpenFileName(this,"Abrir");
    file.setFileName(file_name);
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    if(!file.isOpen())
    {
        QMessageBox::critical(this,"Error",file.errorString());
        return;
    }
    io.setDevice(&file);
    file.flush();
    file.close();

    /*Respaldar ruta para abrir imagenes con OpenCv*/
    picture1_path = file_name.toStdString();

    /*Renderizar imagen en interaz*/
    QPixmap pix(file_name);
    int w = ui->picture_1->width();
    int h = ui->picture_1->height();
    ui->picture_1->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));

    /*Lectura de imagen*/
    image_1 = imread(picture1_path, CV_LOAD_IMAGE_GRAYSCALE);   // Read the file
    if(! image_1.data )                              // Check for invalid input
    {
        cout << "Could not open or find the image" << endl ;
        return;
    }
}

void MainWindow::on_open2_clicked()
{
    QFile file;
    QTextStream io;
    QString file_name;
    file_name = QFileDialog::getOpenFileName(this,"Abrir");
    file.setFileName(file_name);
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    if(!file.isOpen())
    {
        QMessageBox::critical(this,"Error",file.errorString());
        return;
    }
    io.setDevice(&file);
    file.flush();
    file.close();

    /*Respaldar ruta para abrir imagenes con OpenCv*/
    picture2_path = file_name.toStdString();
    
    /*Renderizar imagen en interaz*/
    QPixmap pix(file_name);
    int w = ui->picture_2->width();
    int h = ui->picture_2->height();
    ui->picture_2->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));

    /*Lectura de imagen*/
    image_2 = imread(picture2_path, CV_LOAD_IMAGE_GRAYSCALE);   // Read the file
    if(! image_2.data )                              // Check for invalid input
    {
        /*cout << "Could not open or find the image" << endl ;
        return;*/
        QMessageBox::critical(this,"No se pudo abrir archivo",file.errorString());
        return;        
    }
}

void MainWindow::on_close_clicked()
{
    this -> close();
}

void MainWindow::on_clean1_clicked()
{
    ui->picture_1->clear();
    ui->picture_1->setText("Imagen 1");
}

void MainWindow::on_clean2_clicked()
{
    ui->picture_2->clear();
        ui->picture_1->setText("Imagen 2");
}
