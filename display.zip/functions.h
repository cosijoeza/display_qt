
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
using namespace std;
using namespace cv;
/*NEGATIVOs de una imagen*/
Mat negative(Mat img)
{
    Mat imneg = img.clone();
    int nCanales = img.channels();
    int nRen = img.rows;
    int nCol = img.cols * nCanales;
    int x,y=0;
    for(x = 0; x < nRen; x++)
    {    
        uchar *renglon  = img.ptr<uchar>(x); 
        uchar *negativo = imneg.ptr<uchar>(x);
        for(y = 0; y < nCol; y++)
        {
            *(negativo + y) = ~(*(renglon + y));
        }
    }
    return imneg;
}
/*Operacion AND*/
Mat funAnd(Mat img1,Mat img2)
{
    Mat imand = img1.clone();
    int nCanales = img1.channels();
    int nRen = img1.rows;
    int nCol = img1.cols * nCanales;
    int x,y=0;
    for(x = 0; x < nRen; x++)
    {    
        uchar *renglon_1  = img1.ptr<uchar>(x);
        uchar *renglon_2  = img2.ptr<uchar>(x); 
        uchar *pand = imand.ptr<uchar>(x);
        for(y = 0; y < nCol; y++)
        {
            *(pand + y) = *(renglon_1 + y) & *(renglon_2 + y);
        }
    }
    return imand;
}
/*Operacion OR*/
Mat funOr(Mat img1,Mat img2)
{
    Mat imor = img1.clone();
    int nCanales = img1.channels();
    int nRen = img1.rows;
    int nCol = img1.cols * nCanales;
    int x,y=0;
    for(x = 0; x < nRen; x++)
    {    
        uchar *renglon_1  = img1.ptr<uchar>(x);
        uchar *renglon_2  = img2.ptr<uchar>(x); 
        uchar *por = imor.ptr<uchar>(x);
        for(y = 0; y < nCol; y++)
        {
            *(por + y) = *(renglon_1 + y) | *(renglon_2 + y);
        }
    }
    return imor;
}
/*Operacion RESTA*/
Mat funResta(Mat img1,Mat img2)
{
    Mat imresta = img1.clone();
    int nCanales = img1.channels();
    int nRen = img1.rows;
    int nCol = img1.cols * nCanales;
    int x,y=0;
    for(x = 0; x < nRen; x++)
    {    
        uchar *renglon_1  = img1.ptr<uchar>(x);
        uchar *renglon_2  = img2.ptr<uchar>(x); 
        uchar *pres = imresta.ptr<uchar>(x);
        for(y = 0; y < nCol; y+=nCanales)
        {
            *(pres + y) = abs( *(renglon_1 + y) - *(renglon_2 + y) );
        }
    }
    return imresta;
}
/*Operacion RESTA NORMALIZADA*/
Mat funRestaNorm(Mat img1,Mat img2)
{
    Mat imresta = img1.clone();
    int nCanales = img1.channels();
    int nRen = img1.rows;
    int nCol = img1.cols * nCanales;
    int x,y=0,minimo = 1000,maximo =-1000,resultado;
    /*Obtener valor maximo y minimo de la RESTA entre imagenes*/
    for(x = 0; x < nRen; x++)
    {    
        uchar *renglon_1  = img1.ptr<uchar>(x);
        uchar *renglon_2  = img2.ptr<uchar>(x);
        uchar *pres  =imresta.ptr<uchar>(x);
        for(y = 0; y < nCol; y+=nCanales)
        {
            resultado = *(renglon_1 + y) - *(renglon_2 + y);
            *(pres + y) = resultado;
            if(resultado > maximo)
                maximo = resultado;
            else
                minimo = resultado;
        }
    }
    /*Normalizar imagen*/
    for(x = 0; x < nRen; x++)
    {    
        uchar *pres = imresta.ptr<uchar>(x);
        for(y = 0; y < nCol; y+=nCanales)
        {
            if(maximo == minimo)
                *(pres + y) = 0;
            else    
                *(pres + y) =  int( (*(pres + y) - minimo) / ((maximo - minimo) * 1.0) * 255);
        }
    }
    return imresta;
}
/*Operacion SUMA NORMALIZADA*/
Mat funSuma(Mat img1,Mat img2)
{
    Mat imsuma = img1.clone();
    int nCanales = img1.channels();
    int nRen = img1.rows;
    int nCol = img1.cols * nCanales;
    int x,y=0,maximo =-1000,resultado;
    /*Obtener valor maximo de la SUMA entre imagenes*/
    for(x = 0; x < nRen; x++)
    {    
        uchar *renglon_1  = img1.ptr<uchar>(x);
        uchar *renglon_2  = img2.ptr<uchar>(x);
        uchar *psum  = imsuma.ptr<uchar>(x);
        for(y = 0; y < nCol; y+=nCanales)
        {
            resultado = *(renglon_1 + y) + *(renglon_2 + y);
            *(psum + y) = resultado;
            if(resultado > maximo)
                maximo = resultado;
        }
    }
    /*Normalizar imagen*/
    for(x = 0; x < nRen; x++)
    {    
        uchar *psum = imsuma.ptr<uchar>(x);
        for(y = 0; y < nCol; y+=nCanales)
        {    
            *(psum + y) =  int( (*(psum + y) * 255) / (maximo * 1.0) );
        }
    }
    return imsuma;
}
Mat funGetChannel(Mat img,int bgr)
{
    Mat canal = img.clone();
	int nCan = canal.channels();
	int nRen = img.rows;
	int nCol = img.cols * nCan;
	int c1 = 0,c2 = 0;
    int x,y;
    switch(bgr)
    {
        case 0: //BLUE
            c1 = 1;
            c2 = 2;
            break;
        case 1: //GREEN
            c1 = 0;
            c2 = 2;
            break;  
        case 2: //RED
            c1 = 0;
            c2 = 1;
            break;
    }
    for(x = 0; x < nRen; x++)
    {
        uchar *renglon = canal.ptr<uchar>(x);
        for(y =0; y < nCol; y+=nCan)
        {
            *(renglon + y + c1) = 0;
            *(renglon + y + c2) = 0;
        }
    }
    return canal;
}
/*Escalamiento*/
Mat escala(Mat img,int porcentaje)
{
	int x,y,i,j;
    int nCanales = img.channels();
	int nRen = img.rows,new_Ren;
	int nCol = img.cols * nCanales,new_Col;	
    //Calculo las dimenciones de la nueva imagen
	new_Ren = floor(nRen / porcentaje);
	new_Col = floor(nCol / porcentaje);
	Mat new_image = Mat::zeros(new_Ren,new_Col,CV_8UC1);
	for(x = 0,i = 0; x < nRen; x+=porcentaje,i++)
	{
		uchar * pixelA = img.ptr<uchar>(x);
		uchar * pixelB = new_image.ptr<uchar>(i);
		for ( y = 0,j = 0; y < nCol; y+=porcentaje,j+=nCanales)
		{
			*(pixelB + j) = *(pixelA + y);
		}
	}
	namedWindow("Escalamiento",WINDOW_NORMAL);
    resizeWindow("Escalamiento",new_Ren,new_Col);
    imshow("Escalamiento",new_image);
    return new_image;
}